import React, { useEffect, useState } from 'react';
import Helpers from '../Shared/custom';
import Treeview from '.';
import { render } from "react-dom";


function TreeLeaves(props) {
    const [catagory, setCatagory] = useState(null);
    const [render, setRender] = useState(() => false);
    const [state, setState] = useState(() => props.data);
    const hasChild = !Helpers.isEmpty(state.children);

    
    const callbackFnChild = () => {
     
        let allSelected = state.children?.every((item) => item.isSelected == true);
        if (allSelected) {
            state.isSelected = true;
        } else {
            state.isSelected = false;
        }
        setState(state);
        setRender(!render);
        props.callbackFn(state);
       
    };
   
    
    const onChangeCheckbox = (e) => {
        state.isSelected = !state.isSelected;
        if (state?.children?.length > 0) {
          let output = state.children.map((item) =>
            helperFunction(state.isSelected, item)
          );
          state.children = output;
        }
        setState(prev =>state);
        setRender(!render);
        props.callbackFn(state);
       
    };
    
    const helperFunction = (slug, item) => {
        item.isSelected = slug;
        if (item.children) {
            item.children = item.children.map((el) => helperFunction(slug, el));
        }
        return item;
    };
    

    return (
        <li className="d-tree-node" key={props.keyName+"children"}>
            <div className="d-flex">
                <div className="col mt-10 d-tree-head">
                   <label className="pointer">
                        <input type="checkbox" 
                               data-catagory={state.catagory} 
                               data-index={props.i} 
                               onChange={onChangeCheckbox}
                               checked={state.isSelected}
                               key={`${props.keyName}-checkbox`}
                                /> 
                         <span className="m-l-5">{state.title}</span>
                    </label>
                    <p className="font-10">{state.summary}</p>
                </div>
            </div>
            {
                state.children?.length > 0 &&
                    <div className="d-tree-content">
                          <ul className="d-flex d-tree-container flex-column">
                             {state.children?.map((child,i) =>  
                                <React.Fragment key={child.title+"child"}>
                                    <TreeLeaves  keyName={child.title}
                                        callbackFn={callbackFnChild}
                                        data={child}/>
                                </React.Fragment> 
                             )}
                          </ul>
                    </div>

            }
        </li>
    )
}

export default TreeLeaves
