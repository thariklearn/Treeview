import React, { useEffect, useState } from 'react';
import Helpers from '../Shared/custom';
import TreeLeaves from './TreeLeaves';
import 'bootstrap/dist/css/bootstrap.min.css';
import './index.css';

function Treeview(props) {

    const [state, setState] = useState(() => props.data);
    const [data, setData] = useState(() => []);

    const callbackFn = (data) => {
        let res = state.map((item) => {
                if (data.name == item.name) {
                    item = data;
                }
             return item;
        });

        setData(res)
    };

 

    const allDescendants = (node) => {
        
        if(node.children){
            for (var i = 0; i < node.children.length; i++) {
                var child = node.children[i];
                allDescendants(child);
                var obj = {};
                obj[node.title] = node
                return obj;
              }
        }
    }


    return (
        <React.Fragment>
            <div className="d-tree">
                <ul className="d-flex d-tree-container flex-column p-t-10">
                    {
                        !Helpers.isEmpty(state) &&
                        state.map((list,i)=>(
                            <React.Fragment key={i+"parentDiv"}>
                                    <TreeLeaves callbackFn={callbackFn} data={list} keyName={i+"parent"}/>
                            </React.Fragment>
                            ))
                    }
                </ul>
            
            
            </div>
            <div className="col-md-12 clearfix float-left">
                    <h5 className="col-md-3 ">Selected Variants</h5>
                    <p className="col-md-3">
                            {!Helpers.isEmpty(data) &&
                                data.filter(x=>x.isSelected).map((list,i)=>{
                                return  <span className="tags" key={i+'tags'}>{list.title}{list.children.length >0 && ":"}
                                            {list && list.children && list.children.filter(y=>y.isSelected).map((item,i)=>{
                                                return <span>{item.title}{list.children.length != i+1 && ","}</span>
                                            })}
                                        </span>
                                })
                            }
                    </p>
            </div>
        </React.Fragment>
    )
}

export default Treeview
