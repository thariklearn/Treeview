const data = [
    {
        title:"Phones",
        name:"phones",
        catagory:"phone",
        isSelected:false,
        children:[
            {
                title:"Apple",
                name:"apple",
                catagory:"phones",
                isSelected:false,
                children:[
                    {
                        title:"iphone 6",
                        name:"iphone6",
                        catagory:"apple",
                        isSelected:false,
                        children:[{
                                title:"128GB",
                                name:"128GB",
                                catagory:"apple",
                                summary:"200+ devices",
                                isSelected:false,
                                children:[]
                            },
                            {
                                title:"256GB",
                                name:"256GB",
                                catagory:"apple",
                                summary:"100+ devices",
                                isSelected:false,
                                children:[]
                            },{
                                title:"512GB",
                                name:"512GB",
                                catagory:"apple",
                                summary:"500+ devices",
                                isSelected:false,
                                children:[]
                            }]
                    },
                    {
                        title:"iphone 7",
                        name:"iphone7",
                        catagory:"apple",
                        summary:"200+ devices",
                        isSelected:false,
                    },
                   
                 ]
            },
            {
                title:"Samsung",
                name:"samsung",
                catagory:"phones",
                summary:"500+ Galaxy S21 and 2.5k+ other models",
                isSelected:false,
                children:[]
            },
        ]
    },{
        title:"Computers",
        name:"computers",
        summary:"200+ mac book, 500+ PCs",
        isSelected:false,
        children:[]
    },{
        title:"Watches",
        name:"watches",
        summary:"150+ apple watches,200+ samsung watches",
        isSelected:false,
        children:[]
    },{
        title:"Tvs",
        name:"tvs",
        summary:"20+ samsung Tv,50_ Apple TVs",
        isSelected:false,
        children:[]
    }
];

export default data;