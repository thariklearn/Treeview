import './App.css';
import Treeview from './component/Treeview';
import data from './component/Shared/treeData';

function App() {
  return (
    <div className="App">
          <Treeview data={data}/>
    </div>
  );
}

export default App;
